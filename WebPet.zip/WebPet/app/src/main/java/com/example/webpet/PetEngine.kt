package com.example.webpet

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 웹이 펫의 두뇌 + 물리 + 그리기.
 * 모든 그림과 애니메이션은 이미지 없이 코드(도형)로만 만든다.
 *
 * 캐릭터 좌표계(유닛): 몸통 중심이 (0,0), 머리 중심 (0,-17) 반지름 14, 발끝 y=20.
 * 1유닛 = s 픽셀.
 */
class PetEngine(private val d: Float) {

    enum class State { IDLE, WALK, WAVE, SLEEP, FALL, SWING, HANG, CLIMB, DRAG }

    // ---------- 크기/화면 ----------
    private val s = d * 1.3f               // 유닛 → 픽셀
    var w = 1080f; var h = 2200f
    private val g = 1700f * d              // 중력 (px/s²)

    private val minX get() = 15f * s
    private val maxX get() = w - 15f * s
    private val minY get() = 32f * s
    private val floorY get() = h - 48f * d - 20f * s
    private val anchorTop = 6f * d

    // ---------- 상태 ----------
    var x = 300f; var y = 500f
    private var vx = 0f; private var vy = 0f
    var state = State.FALL; private set
    private var stateT = 0f
    private var nextT = 3f
    private var facing = 1f
    private var rot = 0f
    private var flipping = false
    private var squash = 0f
    private var time = 0f
    private val rnd = Random()

    // 웹(줄)
    private var ropeOn = false
    private var ax = 0f; private var ay = 0f
    private var ropeLen = 0f; private var ropeTarget = 0f
    private var webT = 1f
    private var climbSide = 1f
    private var hangSleep = false

    // 눈
    private var blinkT = 2.5f
    private var blink = 0f
    private var surprised = 0f

    // 팔다리 각도 (라디안, 0 = 아래로 곧게, + = 앞(+x)쪽)
    private var armL = -0.25f; private var armR = 0.25f
    private var legL = -0.1f; private var legR = 0.1f

    // 드래그
    private var dragVx = 0f

    // ---------- 색 ----------
    private val cSky = Color.parseColor("#7EC8F2")
    private val cSkyDark = Color.parseColor("#3E8FC0")
    private val cSkyLight = Color.parseColor("#C8EBFF")
    private val cRed = Color.parseColor("#E53935")
    private val cRedDark = Color.parseColor("#A52422")
    private val cInk = Color.parseColor("#22313A")

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val webPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        color = Color.WHITE; strokeWidth = 1.8f * d
    }
    private val webShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
        color = Color.argb(110, 0, 0, 0); strokeWidth = 3.4f * d
    }
    private val zPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = cSkyDark; textSize = 15f * d; isFakeBoldText = true
    }
    private val path = Path()
    private val rect = RectF()

    // =====================================================================
    //  입력
    // =====================================================================
    fun tap() {
        when (state) {
            State.SLEEP -> { surprised = 1f; vy = -650f * d; vx = 0f; setState(State.FALL) }
            State.SWING -> release(true)
            State.HANG -> { hangSleep = false; release(false) }
            State.DRAG -> {}
            else -> shootWeb()
        }
    }

    fun pet() { // 길게 누르기 → 손 흔들기
        if (state == State.IDLE || state == State.WALK || state == State.SLEEP) {
            vx = 0f; setState(State.WAVE); nextT = 2.2f
        }
    }

    fun beginDrag() {
        ropeOn = false; flipping = false; surprised = 1f
        setState(State.DRAG)
    }

    fun dragTo(px: Float, py: Float, velX: Float) {
        x = px.coerceIn(minX, maxX); y = py.coerceIn(minY, floorY)
        dragVx = velX
    }

    fun endDrag(velX: Float, velY: Float) {
        val cap = 3200f * d
        vx = velX.coerceIn(-cap, cap); vy = velY.coerceIn(-cap, cap)
        flipping = hypot(vx, vy) > 900f * d
        if (abs(vx) > 30f * d) facing = sign(vx)
        setState(State.FALL)
    }

    // =====================================================================
    //  업데이트
    // =====================================================================
    fun update(dtIn: Float) {
        val dt = min(dtIn, 0.05f)
        time += dt; stateT += dt
        squash = max(0f, squash - dt * 4f)
        surprised = max(0f, surprised - dt * 1.5f)
        if (webT < 1f) webT = min(1f, webT + dt / 0.12f)

        // 깜빡임
        blinkT -= dt
        if (blinkT <= 0f) { blink = 1f; blinkT = 2f + rnd.nextFloat() * 3f }
        blink = max(0f, blink - dt * 7f)

        when (state) {
            State.IDLE -> updateIdle()
            State.WALK -> updateWalk(dt)
            State.WAVE -> if (stateT > nextT) toIdle()
            State.SLEEP -> if (stateT > nextT) { toIdle(); squash = 0.6f }
            State.FALL -> updateFall(dt)
            State.SWING -> updateSwing(dt)
            State.HANG -> updateHang(dt)
            State.CLIMB -> updateClimb(dt)
            State.DRAG -> { rot = (-dragVx * 0.00025f / d).coerceIn(-0.6f, 0.6f) }
        }
        updatePose(dt)
    }

    private fun setState(st: State) { state = st; stateT = 0f }

    private fun toIdle() {
        setState(State.IDLE); vx = 0f; vy = 0f; rot = 0f
        nextT = 1.5f + rnd.nextFloat() * 3f
    }

    private fun updateIdle() {
        if (stateT < nextT) return
        val r = rnd.nextFloat()
        when {
            r < 0.38f -> {
                if (rnd.nextFloat() < 0.4f) facing = -facing
                setState(State.WALK); nextT = 2f + rnd.nextFloat() * 4f
            }
            r < 0.68f -> shootWeb()
            r < 0.82f -> { setState(State.SLEEP); nextT = 8f + rnd.nextFloat() * 12f }
            else -> { setState(State.WAVE); nextT = 2f }
        }
    }

    private fun updateWalk(dt: Float) {
        vx = facing * 55f * d
        x += vx * dt
        if (x <= minX || x >= maxX) {
            x = x.coerceIn(minX, maxX)
            if (rnd.nextFloat() < 0.5f) {
                climbSide = if (x <= minX) -1f else 1f
                facing = climbSide
                vx = 0f; setState(State.CLIMB); nextT = 2f + rnd.nextFloat() * 4f
            } else facing = -facing
        }
        if (stateT > nextT) toIdle()
    }

    private fun updateFall(dt: Float) {
        vy += g * dt
        vx *= 0.995f.pow(dt * 60f)
        x += vx * dt; y += vy * dt

        if (flipping) rot += 13f * dt * facing
        else {
            rot = normAngle(rot)
            rot += (0f - rot) * min(1f, dt * 6f)
        }

        if (y <= minY) { y = minY; vy = abs(vy) * 0.2f }

        // 벽에 붙기
        if (x <= minX || x >= maxX) {
            x = x.coerceIn(minX, maxX)
            if (y < floorY - 50f * d) {
                climbSide = if (x <= minX) -1f else 1f
                facing = climbSide; vx = 0f; vy = 0f; rot = 0f; flipping = false
                setState(State.CLIMB); nextT = 1.5f + rnd.nextFloat() * 3f
                squash = 0.4f
                return
            } else vx = -vx * 0.3f
        }

        // 착지
        if (y >= floorY) {
            y = floorY
            squash = min(1f, 0.4f + vy / (1800f * d))
            vy = 0f; rot = 0f; flipping = false
            if (abs(vx) > 200f * d) {
                facing = sign(vx); setState(State.WALK); nextT = 1f
            } else toIdle()
        }
    }

    private fun updateSwing(dt: Float) {
        vy += g * dt
        // 진행 방향으로 살짝 밀어서 그네가 죽지 않게
        if (y > ay + ropeLen * 0.6f) vx += facing * 160f * d * dt
        vx *= 0.999f; vy *= 0.999f
        x += vx * dt; y += vy * dt

        // 줄 감기 (지퍼처럼 끌어올림)
        if (ropeLen > ropeTarget) ropeLen = max(ropeTarget, ropeLen - 700f * d * dt)
        constrainRope()
        collideBounds()

        val dx = x - ax; val dy = y - ay
        val target = atan2(-dx, dy) * 0.75f
        rot += (target - rot) * min(1f, dt * 10f)
        if (abs(vx) > 60f * d) facing = sign(vx)

        // 놓을 타이밍
        val past = (x - ax) * facing > ropeLen * 0.45f && vy < 0f
        if ((stateT > 1.0f && past) || stateT > 4.5f) {
            if (rnd.nextFloat() < 0.3f) startHang() else release(true)
        }
    }

    private fun updateHang(dt: Float) {
        vy += g * dt
        vx += sin(time * 1.4f) * 40f * d * dt
        val damp = 0.25f.pow(dt)
        vx *= damp; vy *= damp
        x += vx * dt; y += vy * dt
        ropeLen += (ropeTarget - ropeLen) * min(1f, dt * 3f)
        constrainRope()
        collideBounds()

        rot += (PI.toFloat() - rot) * min(1f, dt * 5f)
        if (!hangSleep && stateT > nextT * 0.5f && rnd.nextFloat() < 0.004f) hangSleep = true
        if (stateT > nextT) { hangSleep = false; release(false) }
    }

    private fun updateClimb(dt: Float) {
        x = if (climbSide < 0) minX else maxX
        val step = (sin(time * 8f) + 1f) * 0.5f      // 손발 움직임에 맞춰 툭툭 올라감
        y -= 70f * d * step * dt
        if (y <= minY + 10f * d) {
            y = minY + 10f * d
            if (rnd.nextFloat() < 0.5f) {
                ax = x - climbSide * 40f * d; ay = anchorTop
                startHang()
            } else leapOffWall()
            return
        }
        if (stateT > nextT) leapOffWall()
    }

    private fun leapOffWall() {
        facing = -climbSide
        vx = facing * 450f * d; vy = -250f * d
        shootWebAt(
            (x + facing * (150f + rnd.nextFloat() * 180f) * d).coerceIn(minX, maxX),
            anchorTop + rnd.nextFloat() * 30f * d
        )
    }

    // ---------- 웹 ----------
    private fun shootWeb() {
        if (x + facing * 120f * d > maxX || x + facing * 120f * d < minX) facing = -facing
        val tx = (x + facing * (120f + rnd.nextFloat() * 160f) * d).coerceIn(minX, maxX)
        val ty = anchorTop + rnd.nextFloat() * 40f * d
        vy = min(vy, -320f * d)
        vx += facing * 260f * d
        shootWebAt(tx, ty)
    }

    private fun shootWebAt(tx: Float, ty: Float) {
        ax = tx; ay = ty
        ropeLen = hypot(x - ax, y - ay)
        ropeTarget = max(90f * d, ropeLen * 0.72f)
        ropeOn = true; webT = 0f; flipping = false
        setState(State.SWING)
    }

    private fun startHang() {
        ropeOn = true
        ropeTarget = (60f + rnd.nextFloat() * 110f) * d + 20f * s
        ropeLen = max(hypot(x - ax, y - ay), 20f * s)
        hangSleep = false
        setState(State.HANG); nextT = 7f + rnd.nextFloat() * 7f
    }

    private fun release(boost: Boolean) {
        ropeOn = false
        if (boost) { vy -= 220f * d; flipping = rnd.nextFloat() < 0.6f }
        setState(State.FALL)
    }

    private fun constrainRope() {
        val dx = x - ax; val dy = y - ay
        val dist = sqrt(dx * dx + dy * dy)
        if (dist > ropeLen && dist > 0.01f) {
            val nx = dx / dist; val ny = dy / dist
            x = ax + nx * ropeLen; y = ay + ny * ropeLen
            val rv = vx * nx + vy * ny
            if (rv > 0f) { vx -= rv * nx; vy -= rv * ny }
        }
    }

    private fun collideBounds() {
        if (x < minX) { x = minX; vx = abs(vx) * 0.3f }
        if (x > maxX) { x = maxX; vx = -abs(vx) * 0.3f }
        if (y > floorY) { y = floorY; vy = min(vy, 0f) }
        if (y < minY) { y = minY; vy = max(vy, 0f) }
    }

    fun onResize(nw: Float, nh: Float) {
        w = nw; h = nh
        x = x.coerceIn(minX, maxX); y = y.coerceIn(minY, floorY)
        if (ropeOn) { ax = ax.coerceIn(0f, w) }
    }

    // =====================================================================
    //  포즈 (절차적 애니메이션)
    // =====================================================================
    private fun updatePose(dt: Float) {
        var tAL: Float; var tAR: Float; var tLL: Float; var tLR: Float
        val t = time
        when (state) {
            State.IDLE -> {
                val b = sin(t * 2.2f) * 0.06f
                tAL = -0.28f - b; tAR = 0.28f + b; tLL = -0.12f; tLR = 0.12f
            }
            State.WALK -> {
                val p = sin(t * 11f)
                tLL = p * 0.65f; tLR = -p * 0.65f
                tAL = -0.2f - p * 0.55f; tAR = 0.2f + p * 0.55f
            }
            State.WAVE -> {
                tAL = -0.25f; tAR = 2.75f + sin(t * 13f) * 0.4f
                tLL = -0.12f; tLR = 0.12f
            }
            State.SLEEP -> {
                tAL = 0.6f; tAR = 0.5f; tLL = 1.35f; tLR = 1.45f
            }
            State.FALL -> {
                if (flipping) { tAL = 0.9f; tAR = 1.1f; tLL = 1.3f; tLR = 1.2f }
                else {
                    val f = sin(t * 18f) * 0.35f
                    tAL = -2.3f + f; tAR = 2.3f - f
                    tLL = -0.45f - f; tLR = 0.45f + f
                }
            }
            State.SWING -> {
                tAR = webArmAngle()
                tAL = -0.9f + sin(t * 6f) * 0.25f
                val k = (vx * facing / (900f * d)).coerceIn(-1f, 1f)
                tLL = -0.5f * k - 0.2f; tLR = -0.3f * k + 0.1f
            }
            State.HANG -> {
                val sway = sin(t * 1.4f) * 0.15f
                if (hangSleep) { tAL = -2.9f; tAR = 2.9f }
                else { tAL = -2.75f + sway; tAR = 2.75f + sway + sin(t * 3f) * 0.1f }
                tLL = -0.06f; tLR = 0.06f
            }
            State.CLIMB -> {
                val p = sin(t * 8f)
                tAL = 2.4f + p * 0.45f; tAR = 2.4f - p * 0.45f
                tLL = 0.7f - p * 0.4f; tLR = 0.7f + p * 0.4f
            }
            State.DRAG -> {
                val f = sin(t * 16f) * 0.3f
                tAL = -2.7f + f; tAR = 2.7f - f
                val dang = (-dragVx * 0.0006f / d).coerceIn(-1f, 1f) * facing
                tLL = dang - 0.15f + f * 0.5f; tLR = dang + 0.15f - f * 0.5f
            }
        }
        val k = min(1f, dt * 14f)
        armL += (tAL - armL) * k
        armR = if (state == State.SWING) tAR else armR + (tAR - armR) * k
        legL += (tLL - legL) * k
        legR += (tLR - legR) * k
    }

    /** 웹 쏘는 오른팔이 앵커를 정확히 가리키는 각도 */
    private fun webArmAngle(): Float {
        val wx = ax - x; val wy = ay - y
        val c = cos(-rot); val sn = sin(-rot)
        var lx = wx * c - wy * sn
        val ly = wx * sn + wy * c
        lx *= facing
        return atan2(lx, ly)
    }

    // 유닛 좌표 → 화면 좌표
    private fun toWorldX(lx: Float, ly: Float): Float {
        val (sx, sy) = squashScale()
        val px = lx * s * facing * sx; val py = ly * s * sy
        return x + px * cos(rot) - py * sin(rot)
    }
    private fun toWorldY(lx: Float, ly: Float): Float {
        val (sx, sy) = squashScale()
        val px = lx * s * facing * sx; val py = ly * s * sy
        return y + px * sin(rot) + py * cos(rot)
    }
    private fun squashScale() = Pair(1f + 0.18f * squash, 1f - 0.18f * squash)

    // =====================================================================
    //  그리기
    // =====================================================================
    fun draw(c: Canvas) {
        drawShadow(c)
        if (ropeOn) drawWeb(c)
        drawCharacter(c)
        if (state == State.SLEEP || (state == State.HANG && hangSleep)) drawZzz(c)
    }

    private fun drawShadow(c: Canvas) {
        val dist = floorY - y
        if (dist > 400f * d) return
        val a = ((1f - dist / (400f * d)) * 60f).toInt()
        fill.color = Color.argb(a, 0, 0, 0)
        val rw = 12f * s * (1f - dist / (800f * d))
        rect.set(x - rw, floorY + 19f * s, x + rw, floorY + 22.5f * s)
        c.drawOval(rect, fill)
    }

    private fun drawWeb(c: Canvas) {
        val (hx, hy) = if (state == State.HANG)
            Pair(toWorldX(0f, 20f), toWorldY(0f, 20f))
        else {
            val hlx = 7f + sin(armR) * 7.5f; val hly = -1f + cos(armR) * 7.5f
            Pair(toWorldX(hlx, hly), toWorldY(hlx, hly))
        }
        val tx = hx + (ax - hx) * webT
        val ty = hy + (ay - hy) * webT
        c.drawLine(hx, hy, tx, ty, webShadow)
        c.drawLine(hx, hy, tx, ty, webPaint)
        if (webT >= 1f) { // 붙은 자리의 작은 거미줄 뭉치
            for (i in 0 until 6) {
                val a = i * PI.toFloat() / 3f + 0.3f
                val r = 7f * d
                c.drawLine(ax, ay, ax + cos(a) * r, ay + sin(a) * r, webShadow)
                c.drawLine(ax, ay, ax + cos(a) * r, ay + sin(a) * r, webPaint)
            }
        }
    }

    private fun drawCharacter(c: Canvas) {
        val (sx, sy) = squashScale()
        c.save()
        c.translate(x, y)
        c.rotate(Math.toDegrees(rot.toDouble()).toFloat())
        c.scale(s * facing * sx, s * sy)

        val speed = hypot(vx, vy)
        val wind = (speed / (700f * d)).coerceIn(0f, 1f)

        // 1) 머플러 꼬리 (몸 뒤)
        stroke.color = cRedDark; stroke.strokeWidth = 3.6f
        val flutter = sin(time * 15f) * 2.2f * wind + sin(time * 2f) * 0.6f
        path.reset()
        path.moveTo(-3f, -3.5f)
        path.quadTo(-8f - 4f * wind, 1f - 3f * wind + flutter, -7f - 9f * wind, 8f - 10f * wind + flutter * 1.5f)
        c.drawPath(path, stroke)
        stroke.color = cRed; stroke.strokeWidth = 3.2f
        path.reset()
        path.moveTo(-2f, -3.5f)
        path.quadTo(-6f - 5f * wind, 2f - 4f * wind - flutter, -4f - 11f * wind, 10f - 12f * wind - flutter)
        c.drawPath(path, stroke)

        // 2) 다리 + 부츠
        drawLimb(c, -4f, 9f, legL, 7f, 4.6f, 3.4f)
        drawLimb(c, 4f, 9f, legR, 7f, 4.6f, 3.4f)

        // 3) 몸통
        fill.color = cSky
        rect.set(-8f, -5f, 8f, 11f); c.drawRoundRect(rect, 5f, 5f, fill)
        fill.color = cSkyLight
        rect.set(-4.5f, -1f, 4.5f, 7f); c.drawOval(rect, fill)
        fill.color = cRed
        rect.set(-8f, 5.2f, 8f, 7.4f); c.drawRect(rect, fill)          // 벨트
        fill.color = Color.WHITE
        c.drawCircle(0f, 6.3f, 1.4f, fill)                             // 벨트 버클

        // 4) 팔 + 장갑
        drawLimb(c, -7f, -1f, armL, 7.5f, 4f, 3.2f)
        drawLimb(c, 7f, -1f, armR, 7.5f, 4f, 3.2f)

        // 5) 머플러 목 부분
        fill.color = cRed
        rect.set(-9.5f, -6.5f, 9.5f, -1f); c.drawRoundRect(rect, 2.8f, 2.8f, fill)
        stroke.color = cRedDark; stroke.strokeWidth = 0.8f
        c.drawLine(-6f, -5.5f, -5f, -2f, stroke); c.drawLine(4f, -5.5f, 5f, -2f, stroke)

        // 6) 머리
        fill.color = cSky
        c.drawCircle(0f, -17f, 14f, fill)
        stroke.color = cSkyDark; stroke.strokeWidth = 1.1f
        c.drawCircle(0f, -17f, 14f, stroke)
        fill.color = Color.argb(120, 255, 255, 255)
        rect.set(-9f, -28f, -3f, -24f); c.drawOval(rect, fill)          // 하이라이트
        // 작은 더듬이 두 개
        stroke.color = cSkyDark; stroke.strokeWidth = 1.2f
        c.drawLine(-3f, -30.5f, -5.5f, -35f, stroke)
        c.drawLine(3f, -30.5f, 5.5f, -35f, stroke)
        fill.color = cRed
        c.drawCircle(-5.5f, -35f, 1.6f, fill); c.drawCircle(5.5f, -35f, 1.6f, fill)

        // 7) 고글 줄 + 고글
        stroke.color = cRedDark; stroke.strokeWidth = 2.4f
        c.drawLine(-13.6f, -18f, 13.6f, -18f, stroke)
        val closed = blink > 0.5f || state == State.SLEEP || (state == State.HANG && hangSleep)
        drawGoggle(c, -4.2f, -17.5f, closed)
        drawGoggle(c, 7.2f, -17.5f, closed)

        // 8) 볼터치 + 입
        fill.color = Color.argb(90, 255, 120, 140)
        c.drawCircle(-6f, -9.5f, 2f, fill); c.drawCircle(10.5f, -9.5f, 1.8f, fill)
        if (surprised > 0.2f) {
            fill.color = cInk; c.drawCircle(2.5f, -8.5f, 1.6f, fill)
        } else {
            stroke.color = cInk; stroke.strokeWidth = 1f
            rect.set(0f, -11f, 5f, -7.5f); c.drawArc(rect, 20f, 140f, false, stroke)
        }
        c.restore()
    }

    private fun drawLimb(c: Canvas, ox: Float, oy: Float, a: Float, len: Float, width: Float, endR: Float) {
        val ex = ox + sin(a) * len; val ey = oy + cos(a) * len
        stroke.color = cSkyDark; stroke.strokeWidth = width + 0.9f
        c.drawLine(ox, oy, ex, ey, stroke)
        stroke.color = cSky; stroke.strokeWidth = width
        c.drawLine(ox, oy, ex, ey, stroke)
        fill.color = cRed
        c.drawCircle(ex, ey, endR, fill)
        stroke.color = cRedDark; stroke.strokeWidth = 0.7f
        c.drawCircle(ex, ey, endR, stroke)
    }

    private fun drawGoggle(c: Canvas, cx: Float, cy: Float, closed: Boolean) {
        fill.color = cRed; c.drawCircle(cx, cy, 5.3f, fill)
        stroke.color = cRedDark; stroke.strokeWidth = 0.8f; c.drawCircle(cx, cy, 5.3f, stroke)
        fill.color = Color.WHITE; c.drawCircle(cx, cy, 4f, fill)
        if (closed) {
            stroke.color = cInk; stroke.strokeWidth = 1.1f
            rect.set(cx - 2.6f, cy - 2f, cx + 2.6f, cy + 1.6f)
            c.drawArc(rect, 10f, 160f, false, stroke)
        } else {
            val lookX = 1.2f
            val lookY = if (state == State.FALL || state == State.DRAG) -0.8f else 0.3f
            val pr = if (surprised > 0.2f) 1.3f else 1.9f
            fill.color = cInk; c.drawCircle(cx + lookX, cy + lookY, pr, fill)
            fill.color = Color.WHITE; c.drawCircle(cx + lookX + 0.6f, cy + lookY - 0.7f, 0.6f, fill)
        }
        fill.color = Color.argb(70, 126, 200, 242)
        rect.set(cx - 3.2f, cy - 3.6f, cx - 0.6f, cy - 1.6f); c.drawOval(rect, fill)
    }

    private fun drawZzz(c: Canvas) {
        val hx = toWorldX(4f, -28f); val hy = toWorldY(4f, -28f)
        for (i in 0 until 3) {
            val p = ((time * 0.5f + i / 3f) % 1f)
            zPaint.alpha = ((1f - p) * 255).toInt()
            zPaint.textSize = (10f + p * 8f) * d
            c.drawText("z", hx + p * 18f * d + sin(p * 6f) * 3f * d, hy - p * 40f * d, zPaint)
        }
    }

    private fun normAngle(a: Float): Float {
        var r = a % (2f * PI.toFloat())
        if (r > PI) r -= 2f * PI.toFloat()
        if (r < -PI) r += 2f * PI.toFloat()
        return r
    }
}
