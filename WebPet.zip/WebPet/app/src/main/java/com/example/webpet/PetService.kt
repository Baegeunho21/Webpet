package com.example.webpet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.view.WindowManager

/** 화면 최상위에 투명 오버레이 창을 띄우고 PetView를 올리는 포그라운드 서비스 */
class PetService : Service() {

    private var overlay: PetOverlay? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = PetOverlay(this, wm).also { it.show() }
    }

    override fun onDestroy() {
        overlay?.hide(); overlay = null
        super.onDestroy()
    }

    private fun startAsForeground() {
        val channelId = "webpet"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "웹이 펫", NotificationManager.IMPORTANCE_MIN)
        )
        val tap = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, channelId)
            .setContentTitle("웹이가 화면에서 놀고 있어요")
            .setSmallIcon(android.R.drawable.star_on)
            .setContentIntent(tap)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, notif)
        }
    }
}
