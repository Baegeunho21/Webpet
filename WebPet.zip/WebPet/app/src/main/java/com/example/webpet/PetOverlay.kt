package com.example.webpet

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.PixelFormat
import android.os.Build
import android.os.SystemClock
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.WindowManager
import kotlin.math.hypot

/**
 * 창 2개로 구성:
 *  1) 렌더 창: 화면 전체, 터치 통과(NOT_TOUCHABLE). 캐릭터와 거미줄을 그림.
 *     Android 12+는 터치 통과 오버레이의 불투명도가 0.8 이하여야 해서 alpha = 0.8.
 *  2) 터치 창: 캐릭터 크기의 투명 창이 캐릭터를 따라다니며 탭/드래그를 받음.
 *  → 펫을 만지지 않는 곳은 아래 앱이 정상적으로 터치됨.
 */
class PetOverlay(private val ctx: Context, private val wm: WindowManager) {

    private val d = ctx.resources.displayMetrics.density
    val engine = PetEngine(d)

    private val renderView = RenderView(ctx)
    private val touchView = TouchView(ctx)
    private val touchSize = (84 * d).toInt()

    private val renderParams = baseParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    ).apply { alpha = 0.8f }

    private val touchParams = baseParams(touchSize, touchSize, 0)

    private var running = false
    private var lastNanos = 0L
    private var offX = 0; private var offY = 0
    private val loc = IntArray(2)

    private fun baseParams(w: Int, h: Int, extra: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED or extra,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 30) {
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
    }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(nanos: Long) {
            if (!running) return
            val dt = if (lastNanos == 0L) 0.016f else (nanos - lastNanos) / 1e9f
            lastNanos = nanos
            engine.update(dt)
            renderView.invalidate()
            moveTouchWindow()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun show() {
        wm.addView(renderView, renderParams)
        wm.addView(touchView, touchParams)
        running = true
        Choreographer.getInstance().postFrameCallback(frame)
    }

    fun hide() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
        runCatching { wm.removeView(touchView) }
        runCatching { wm.removeView(renderView) }
    }

    private fun moveTouchWindow() {
        if (!touchView.isAttachedToWindow || touchView.dragging) return
        val nx = (engine.x + offX - touchSize / 2f).toInt()
        val ny = (engine.y + offY - touchSize * 0.6f).toInt()
        if (kotlin.math.abs(nx - touchParams.x) + kotlin.math.abs(ny - touchParams.y) > 2) {
            touchParams.x = nx; touchParams.y = ny
            wm.updateViewLayout(touchView, touchParams)
        }
    }

    // ---------------- 렌더 창 ----------------
    private inner class RenderView(ctx: Context) : View(ctx) {
        override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
            getLocationOnScreen(loc)
            offX = loc[0]; offY = loc[1]
            engine.onResize(w.toFloat(), h.toFloat())
        }
        override fun onDraw(canvas: Canvas) = engine.draw(canvas)
    }

    // ---------------- 터치 창 ----------------
    private inner class TouchView(ctx: Context) : View(ctx) {
        var dragging = false
        private var downX = 0f; private var downY = 0f; private var downTime = 0L
        private var grabDy = 0f
        private var tracker: VelocityTracker? = null
        private val slop = 8f * d

        @SuppressLint("ClickableViewAccessibility")
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; downTime = SystemClock.uptimeMillis()
                    dragging = false
                    grabDy = engine.y - (e.rawY - offY)
                    tracker?.recycle(); tracker = VelocityTracker.obtain()
                    tracker?.addMovement(e)
                }
                MotionEvent.ACTION_MOVE -> {
                    tracker?.addMovement(e)
                    if (!dragging && hypot(e.rawX - downX, e.rawY - downY) > slop) {
                        dragging = true; engine.beginDrag()
                    }
                    if (dragging) {
                        tracker?.computeCurrentVelocity(1000)
                        engine.dragTo(e.rawX - offX, e.rawY - offY + grabDy, tracker?.xVelocity ?: 0f)
                        touchParams.x = (e.rawX - touchSize / 2f).toInt()
                        touchParams.y = (e.rawY - touchSize / 2f).toInt()
                        wm.updateViewLayout(this, touchParams)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    tracker?.addMovement(e)
                    tracker?.computeCurrentVelocity(1000)
                    if (dragging) {
                        engine.endDrag(tracker?.xVelocity ?: 0f, tracker?.yVelocity ?: 0f)
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        if (SystemClock.uptimeMillis() - downTime > 500) engine.pet() else engine.tap()
                    }
                    dragging = false
                    tracker?.recycle(); tracker = null
                }
            }
            return true
        }
    }
}
