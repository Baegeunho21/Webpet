package com.example.webpet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val info = TextView(this).apply {
            text = "웹이를 화면 위에 띄웁니다.\n'다른 앱 위에 표시' 권한이 필요해요."
            textSize = 18f
            gravity = Gravity.CENTER
        }
        val start = Button(this).apply {
            text = "펫 시작"
            setOnClickListener { startPet() }
        }
        val stop = Button(this).apply {
            text = "펫 종료"
            setOnClickListener { stopService(Intent(this@MainActivity, PetService::class.java)) }
        }
        layout.addView(info)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun startPet() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        startForegroundService(Intent(this, PetService::class.java))
        moveTaskToBack(true)
    }
}
